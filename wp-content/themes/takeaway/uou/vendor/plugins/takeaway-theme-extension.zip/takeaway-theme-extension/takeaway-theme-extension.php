<?php

/*
  Plugin Name: Takeaway Theme Extension
  Plugin URI: https://uouapps.com
  Description: Basic theme functionality for casa like custom post type , custom taxonomy , shortcodes etc.
  Version: 1.0.0
  Author: Uouapps
  Author URI: http://www.uouapps.com
  
 */


	include( 'cuztom/cuztom.php' );
	include( 'shortcodes/shortcodes.php' );
	include( 'cpt/page_meta.php');
	include( 'cpt/post_meta.php');


